# Submission package — Computers and Electronics in Agriculture

Upload the whole folder (or the zip) to Overleaf and set **main.tex** as the compile target.

## Build
Requires the Elsevier CAS class (`cas-dc.cls`, `cas-model2-names.bst`) - on Overleaf
start from the **Elsevier CAS** template, or the files are on CTAN. Compile order:

    pdflatex main -> bibtex main -> pdflatex main -> pdflatex main

Two BibTeX-dependent passes are needed or citations render as `?`.

## Contents
- `main.tex` — manuscript (cas-dc, double column, same layout as the authors' ASR submission)
- `refs.bib` — 20 entries, all verified against the published record
- `tab_*.tex` — 7 tables, generated from the result files; do not hand-edit
- `figures/Figure_1..10.png` — 300 dpi, renamed in order of appearance
- `highlights.txt` — upload separately in Editorial Manager, as the guide requires

## Remaining author actions
1. **Data availability** — the journal applies Option C, which *requires* the data to be deposited,
   cited and linked. Replace `PENDING-ZENODO-DOI` in `main.tex` with a real DOI (mint one by linking
   the GitHub repo to Zenodo), or make the repository public and use that URL.
2. **Graphical abstract** — encouraged, not required. 531 x 1328 px minimum, submitted separately.
3. **Corresponding author** needs a full postal address and phone number in Editorial Manager.

## Regenerating
Tables and figures are generated, never typed:

    python docs/paper/make_tex_tables.py
    python docs/paper/make_figures.py
    python scripts/build_submission.py
